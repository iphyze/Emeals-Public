<div class="footer">
        <div class="footer-box">
                <h1 class="wow fadeIn" data-wow-delay=".5s"><a href="/emeals/"><i class="fas fa-hamburger"></i> E-Meals</a></h1>
                <p class="wow fadeIn" data-wow-delay=".5s">Emeals aims to satisfy you with the best dishes available in and out of your region, we give you that satisfaction you desire with our top notch service delivery.</p>
        </div>
        <div class="footer-box">
            <h3 class="wow fadeIn" data-wow-delay="1s">Get in Touch with us for Good Foods & Premium Services, making our kitchen your satisfaction.</h3>
            <p class="wow fadeIn" data-wow-delay="1s">Visit our contact page to get in touch with us through our various social media platforms, contact address, email or phone number. We are always available.</p>
        </div>
        <div class="footer-box">
            <h3 class="wow fadeIn" data-wow-delay="1.5s">Quick Links</h3>
            <a href="/emeals/" class="wow fadeIn" data-wow-delay="1.5s">Home</a>
            <a href="account.php" class="wow fadeIn" data-wow-delay="1.5s">Log In</a>
            <a href="account.php" class="wow fadeIn" data-wow-delay="1.5s">Register</a>
            <a href="profile.php" class="wow fadeIn" data-wow-delay="1.5s">Profile</a>
            <a href="/admin" class="wow fadeIn" data-wow-delay="2s">Admin</a>
        </div>
        <div class="footer-box">
            <h3 class="wow fadeIn" data-wow-delay="2s">Other Links</h3>
            <a href="cart.php" class="wow fadeIn" data-wow-delay="2s">Cart</a>
            <a href="contact.php" class="wow fadeIn" data-wow-delay="2s">Contact</a>
            <a href="store.php" class="wow fadeIn" data-wow-delay="2s">All Foods</a>
            <a href="checkout.php" class="wow fadeIn" data-wow-delay="2s">Checkout</a>
        </div>
</div>
<div class="footer-main">
    &copy; Electronic Meals Incorporated 2021
</div>